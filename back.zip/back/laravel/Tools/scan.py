import requests, os, time, socket
from multiprocessing.pool import ThreadPool
from colorama import Fore, Back, Style

red = Fore.RED
green = Fore.GREEN
white = Fore.WHITE

try:
    os.mkdir('Result')
except:
    pass
os.system("title Multi Scanner Author By Haxgeno7 ")

def cr():
    try:
        if os.name == 'nt':
            os.system('cls')
        else:
            os.system('clear')
    except:
        pass


def key():
    try:
        print(f"""
 ____   ___   ___ _____  D Z P R I V L E A K  S C A N N E R
| __ ) / _ \ / _ \_   _|  +  MASS ENV + DEBUG SCANNER
|  _ \| | | | | | || |    +  MASS MAILLER PHP SCANNER
| |_) | |_| | |_| || |    +  MASS CVE-2020–25213 0DAY SCAN
|____/ \___/ \___/ |_|    +  AUTO MULTI THREAD TOOLS

        TELEGRAM OFFICIAL 
    Join : https://t.me/dzleakpriv

""")
        lwl = requests.get('https://raw.githubusercontent.com/maschil/bypas/main/ya.txt')
        so2al = open('LICENSE.txt', 'r').readlines()
        br = str(so2al)
        if br in str(lwl.content):
            print('[+] Welcome USER ...')
            time.sleep(5)
        else:
            so2al1 = input(' [+] Input License : '.format(fw, sb))
            tani = requests.get('https://raw.githubusercontent.com/maschil/bypas/main/ya.txt')
            br = str(so2al1)
            if str(br) in str(tani.content):
                print('[+] Welcome USER ..'.format(fw, sb))
                time.sleep(5)
            else:
                print('\n[-] LICENSE KEY INCORRECT!')
                time.sleep(5)
                sys.exit()
    except:
        try:
            so2al1 = input('[-] Give Me License : ')
            tani = requests.get('https://raw.githubusercontent.com/maschil/bypas/main/ya.txt')
            br = str(so2al1)
            if str(br) in str(tani.content):
                print('[+] Welcome USER ..')
                z = open('LICENSE.txt', 'w').write(so2al1)
            else:
                print('[-] LICENSE KEY INCORRECT!'.format(fr, sb))
                time.sleep(1)
                sys.exit()
        except Exception as f:
            exit()
def start():
    cr()
    key()
    cr()
start()
def cms(url):
    try:
        url = url.replace('\n', '').replace('\r', '')
        if url.startswith('http://'):
            url = url.replace('http://', '')
        elif url.startswith('https://'):
            url = url.replace('https://', '')
        op = requests.get('http://' + url + '/.env', timeout=10)
        op2 = requests.get('http://' + url + '/leafmailer2.8(1).php', timeout=10)
        op3 = requests.get('http://' + url + '/wp-content/plugins/wp-file-manager/lib/php/connector.minimal.php', timeout=10)
        op4 = requests.get('http://' + url + '/leafmailer2.8.php', timeout=10)
        op5 = requests.get('http://' + url + '/leafmailer.php', timeout=10)
        op6 = requests.get('http://' + url + '/leaf.php', timeout=10)
        op7 = requests.get('http://' + url + '/send.php', timeout=10)
        op8 = requests.get('http://' + url + '/sender.php', timeout=10)
        op9 = requests.get('http://' + url + '/mail.php', timeout=10)
        op10 = requests.get('http://' + url + '/wp-content/leafmailer2.8.php', timeout=10)
        op11 = requests.get('http://' + url + '/wp-includes/leafmailer2.8.php', timeout=10)
        op12 = requests.get('http://' + url + '/wp-admin/leafmailer2.8.php', timeout=10)
        if ('APP_NAME' or 'DB_DATABASE') in op.text:
            print(' [ God Env ] http://' + url + '\n')
            open('Result/Good-env.txt', 'a').write('http://' + url + '\n')
        elif 'Leaf PHPMailer' in op2.text:
            print(' [ Vuln ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/leafmailer2.8(1).php\n')
        elif '{"error":["errUnknownCmd"]}' in op3.text:
            print(' [ Vuln ] http://' + url + '\n')
            open('Result/Vuln-0day.txt', 'a').write('http://' + url + '/wp-content/plugins/wp-file-manager/lib/php/connector.minimal.php\n')
        elif 'Leaf PHPMailer' in op4.text:
            print(' [ Vuln ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/leafmailer2.8.php\n')
        elif 'Sender Name' in op5.text:
            print(' [ Vuln ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/leafmailer.php\n')
        elif 'Leaf PHPMailer' in op6.text:
            print(' [ Vuln ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/leaf.php\n')
        elif 'Message Type' in op7.text:
            print(' [ Vuln ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/send.php\n')
        elif 'Message encoding' in op8.text:
            print(' [ Vuln ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/sender.php\n')
        elif 'Message Letter' in op9.text:
            print(' [ Vuln ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/mail.php\n')
        elif 'Leaf PHPMailer' in op10.text:
            print(' [ God Debug ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/wp-content/leafmailer2.8.php\n')
        elif 'Leaf PHPMailer' in op11.text:
            print(' [ God Debug ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/wp-includes/leafmailer2.8.php\n')
        elif 'Leaf PHPMailer' in op12.text:
            print(' [ God Debug ] http://' + url + '\n')
            open('Result/Leafmailer2.8.txt', 'a').write('http://' + url + '/wp-admin/leafmailer2.8.php\n')
        else:
            print('[Bad] http://' + url + '\n')
    except:
        pass

banner =  '''
 ____   ___   ___ _____  H A X G E N O 7  S C A N N E R
| __ ) / _ \ / _ \_   _|  +  MASS ENV + DEBUG SCANNER
|  _ \| | | | | | || |    +  MASS MAILLER PHP SCANNER
| |_) | |_| | |_| || |    +  MASS CVE-2020–25213 0DAY SCAN
|____/ \___/ \___/ |_|    +  AUTO MULTI THREAD TOOLS
'''
print(banner)

DavidBilla = open(input('[+] Ips Or Web list : '), 'r').readlines()
DB = input('[+] Give Me Thread : ')
pool = ThreadPool(int(DB))
pool.map(cms, DavidBilla)
pool.close()
pool.join()
if __name__ == '__main__':
    print('Success Scan !! Check Folder good_env.txt')
