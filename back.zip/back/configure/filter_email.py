#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os
import time
import random
import re
from colorama import Fore, init

# Initialize colorama
init(autoreset=True)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def file_to_str():
    filename = input(f'\n{Fore.RED}[{Fore.WHITE}!{Fore.RED}]{Fore.WHITE} Name List: ')
    with open(filename, encoding='utf-8') as f:
        return f.read().lower()


def get_emails(s):
    awww = re.compile(r'''(
                   ([a-zA-Z0-9._%+-]+)
                    @
                    (gmail|yahoo|hotmail)
                    (.com)
                    )''', re.VERBOSE)
    return (email[0] for email in re.findall(awww, s) if not email[0].startswith('//'))

def main():
    try:
        result_folder = "Result"
        if not os.path.exists(result_folder):
            os.mkdir(result_folder)

        for email in get_emails(file_to_str()):
            if 'gmail' in email:
                print(f'{Fore.RED}[{Fore.WHITE}!{Fore.RED}]{Fore.WHITE} Detected Gmail {Fore.YELLOW} > {email}')
                with open(os.path.join(result_folder, 'gmail-file.txt'), 'a') as f:
                    f.write(email + '\n')
            elif 'yahoo' in email:
                print(f'{Fore.RED}[{Fore.WHITE}!{Fore.RED}]{Fore.WHITE} Detected Yahoo {Fore.YELLOW} > {email}')
                with open(os.path.join(result_folder, 'yahoo-file.txt'), 'a') as f:
                    f.write(email + '\n')
            elif 'hotmail' in email:
                print(f'{Fore.RED}[{Fore.WHITE}!{Fore.RED}]{Fore.WHITE} Detected Hotmail {Fore.YELLOW} > {email}')
                with open(os.path.join(result_folder, 'hotmail-file.txt'), 'a') as f:
                    f.write(email + '\n')
            else:
                print(f'{Fore.RED}[{Fore.WHITE}!{Fore.RED}]{Fore.WHITE} Detected Random Mail {Fore.YELLOW} > {email}')
                with open(os.path.join(result_folder, 'random.txt'), 'a') as f:
                    f.write(email + '\n')

        print(f'{Fore.GREEN}[+] Success filter Saved In Folder {result_folder} [+]')
    except Exception as e:
        print(f'{Fore.RED}Error Description: {e}')

if __name__ == '__main__':
    main()
