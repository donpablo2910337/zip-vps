def generate_port_combinations(input_file, output_file):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    with open(output_file, 'w') as f:
        for line in lines:
            if line.strip():
                parts = line.strip().rsplit('@', 1)
                if len(parts) == 2:
                    username = parts[0].split(':')[0].replace('|', '').replace('-', '').replace('!', '')
                    domain_and_password = parts[-1].split(':')
                    domain = domain_and_password[0].replace('|', '').replace('-', '').replace('!', '')
                    password = ':'.join(domain_and_password[1:])
                    ports = ['2082', '2083', '2086', '2087']
                    for port in ports:
                        url = f"https://{domain}:{port}|{username}|{password}\n"
                        f.write(url)
                else:
                    print(f"Ignoring line: {line.strip()} - Incorrect format")

input_file = input("Combolist: ")
output_file = "Result/PortsCombo.txt"

generate_port_combinations(input_file, output_file)
print(f"Generated combinations saved in {output_file}")
