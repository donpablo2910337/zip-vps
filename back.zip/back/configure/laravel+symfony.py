#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os
import time
import random
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from concurrent.futures import ThreadPoolExecutor
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

# Suppress only the single InsecureRequestWarning from urllib3 needed for requests
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def check_framework(exploit_v4):
    if not exploit_v4.startswith("http"):
        exploit_v4 = "http://" + exploit_v4
    try:
        response = requests.get(exploit_v4, timeout=5, verify=False)
        if "symfony/profiler/" in response.text or "symfony" in response.text:
            print(f"- {exploit_v4}  -> |{Fore.GREEN} SYMFONY + APACHE {Style.RESET_ALL}|")
            with open('Result/symfony-valid-web.txt', 'a') as f:
                f.write(exploit_v4 + '\n')
        elif "laravel_session" in response.cookies:
            print(f"- {exploit_v4}  -> |{Fore.GREEN} LARAVEL {Style.RESET_ALL}|")
            with open('Result/laravel-valid-web.txt', 'a') as f:
                f.write(exploit_v4 + '\n')
        elif "wp-content/" in response.text:
            print(f"- {exploit_v4}  -> |{Fore.GREEN} WORDPRESS {Style.RESET_ALL}|")
            with open('Result/wordpress-valid-web.txt', 'a') as f:
                f.write(exploit_v4 + '\n')
        else:
            response2 = requests.get(exploit_v4 + "/_profiler/empty/search/results", timeout=5, verify=False)
            if "symfony/profiler/" in response2.text or "symfony" in response2.text:
                print(f"- {exploit_v4}  -> |{Fore.GREEN} SYMFONY + NGINX {Style.RESET_ALL}|")
                with open('Result/symfony-valid-web.txt', 'a') as f:
                    f.write(exploit_v4 + '\n')
            else:
                print(f"- {exploit_v4} -> |{Fore.GREEN}Unknown Framework{Style.RESET_ALL}|")
                with open('Result/unknown-live.txt', 'a') as f:
                    f.write(exploit_v4 + '\n')
    except:
        print(f"- {exploit_v4} -> |{Fore.RED}BAD IPS/LOW RESPOND{Style.RESET_ALL}|")

def main():
    clear_screen()
    t1 = time.perf_counter()
    
    if not os.path.exists("Result"):
        os.mkdir("Result")

    sitelists = input(f"{Fore.WHITE}|{Fore.RED}INPUT{Fore.WHITE}| Enter List File Web: {Style.RESET_ALL}")
    if not os.path.exists(sitelists):
        print(f"{Fore.RED}The list not found in current dir{Style.RESET_ALL}")
        return
    
    try:
        with open(sitelists, "r", encoding="utf8", errors='ignore') as f:
            inputlist = f.read().splitlines()
        threadblue = input(f"{Fore.WHITE}|{Fore.RED}INPUT{Fore.WHITE}| Thread: {Style.RESET_ALL}")
        thread_count = int(threadblue)
    except Exception as e:
        print(f"{Fore.RED}An error occurred: {e}{Style.RESET_ALL}")
        return
    
    if inputlist:
        try:
            with ThreadPoolExecutor(thread_count) as executor:
                executor.map(check_framework, inputlist)

            t2 = time.perf_counter()
            print(f'MultiThreaded Code Took: {t2 - t1} seconds')
            print('Script Already Done')
        except Exception as e:
            print(f"{Fore.RED}An error occurred during execution: {e}{Style.RESET_ALL}")

if __name__ == '__main__':
    main()
