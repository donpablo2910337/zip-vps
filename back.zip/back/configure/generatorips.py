#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os
import time
import random
from colorama import Fore, Style, init
from rich import print as rich_print

# Initialize colorama
init(autoreset=True)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_logo(logo):
    colors = [Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN, Fore.WHITE]
    clear_screen()
    for line in logo.splitlines():
        rich_print(f"[{random.choice(colors)}]{line}[/{random.choice(colors)}]")
        time.sleep(0.05)

def generate_ips(count):
    with open('Result/generator-ips.txt', 'a') as file:
        for _ in range(count):
            a = random.randint(0, 225)
            b = random.randint(0, 225)
            c = random.randint(0, 225)
            d = random.randint(0, 225)
            ip = f'{a}.{b}.{c}.{d}'
            rich_print(f"[red]| [green]{ip}[red] | [white] GENERATOR IP > [yellow]exploit_v4")
            file.write(ip + '\n')

def main():
    clear_screen()
    while True:
        try:
            num_ips = int(input("How many IPS? : "))
            break
        except ValueError:
            rich_print("[red]Please enter a valid number.[/red]")
    
    generate_ips(num_ips)

if __name__ == '__main__':
    main()
