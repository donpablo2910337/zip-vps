#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os
import time
import random
import requests
import json
import re
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def SendgridCheck(apikey):
    try:
        url = 'https://api.sendgrid.com/v3/user/credits'
        headers = {"authorization": "Bearer "+ apikey }
        getInfo = requests.get(url, headers=headers)
        limit = json.loads(getInfo.text)['total']
        used = json.loads(getInfo.text)['used']
        reset = json.loads(getInfo.text)['reset_frequency']
        print()
        print(f'{Fore.WHITE}[{Fore.RED}!{Fore.WHITE}]{Fore.WHITE} Limit Sendgrid : {Fore.WHITE}{limit}')
        print(f'{Fore.WHITE}[{Fore.RED}!{Fore.WHITE}]{Fore.WHITE} Already Used   : {Fore.WHITE}{used}')
        print(f'{Fore.WHITE}[{Fore.RED}!{Fore.WHITE}]{Fore.WHITE} Reset Timee    : {Fore.WHITE}{reset}')
        with open("Pegasus1337/sendgridcheck-results.txt", "a") as x:
            x.write(f"APIKEY: {apikey}\nLimit: {limit}\nUsed: {used}\nReset: {reset}\n\n")
        print('\n ___________________{Fore.RED}VLISTEXCHECKER{Fore.WHITE}__________________________ ')
    except Exception as e:
        print('\n')
        print(f'{Fore.WHITE}[{Fore.RED}!{Fore.WHITE}]{Fore.WHITE} Cant Access    :{Fore.WHITE}', str(e))
        print(f'\n___________________{Fore.RED}VLISTEXCHECKER{Fore.WHITE}_____________________________')

def main():
    clear_screen()
    try:
        filename = input(f'{Fore.WHITE}[{Fore.RED}!{Fore.WHITE}]{Fore.WHITE} Input List: ')
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
            for line in lines:
                try:
                    if not ("[" in line and "SENDGRID_API_KEY" in line and "=" in line):
                        line = "SENDGRID_API_KEY = " + line.replace(" ", "")
                    apikey = re.findall("SENDGRID_API_KEY = (.*)", line)[0]
                    print(f'{Fore.WHITE}[{Fore.RED}!{Fore.WHITE}]{Fore.WHITE} ApiKey: {apikey.strip()}')
                    SendgridCheck(apikey.strip())
                except Exception as e:
                    continue
    except Exception as e:
        pass

if __name__ == '__main__':
    main()
