from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time
from urllib.parse import urlparse

RESET = "\033[0m"
GREEN = "\033[32m"
RED = "\033[31m"

def setup_driver():
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    return driver

def read_keywords_from_file(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        keywords = [line.strip() for line in file.readlines() if line.strip()]
    return keywords

def get_google_search_results(driver, keyword):
    query = '+'.join(keyword.split())
    url = f"https://www.google.com/search?q={query}&num=100"
    driver.get(url)
    time.sleep(0.5)
    return driver.page_source

def parse_google_search_results(html_source):
    soup = BeautifulSoup(html_source, 'html.parser')
    if "Our systems have detected unusual traffic from your computer network" in soup.text:
        return "captcha"
    
    results = []
    for result in soup.find_all('div', class_='tF2Cxc'):
        link = result.find('a')['href']
        results.append(link)
    return results

def extract_domain(url):
    parsed_uri = urlparse(url)
    if parsed_uri.scheme in ['http', 'https']:
        return f"{parsed_uri.scheme}://{parsed_uri.netloc}"
    return None

def write_results_to_file(results, output_type='domain'):
    if output_type == 'domain':
        filename = 'result_domain.txt'
        with open(filename, 'a', encoding='utf-8') as file:
            for link in results:
                domain = extract_domain(link)
                if domain:
                    file.write(f"{domain}\n")
    elif output_type == 'fullurl':
        filename = 'result_fullurl.txt'
        with open(filename, 'a', encoding='utf-8') as file:
            for link in results:
                file.write(f"{link}\n")

def clear_browser_data(driver):
    # Open a new tab
    driver.execute_script("window.open('');")
    # Switch to the new tab
    driver.switch_to.window(driver.window_handles[1])
    # Navigate to clear browsing data settings
    driver.get('chrome://settings/clearBrowserData')
    time.sleep(2)
    # Wait for the settings page to load
    actions = webdriver.ActionChains(driver)
    # Use keyboard shortcuts to navigate and clear data
    actions.send_keys(Keys.TAB * 3 + Keys.ENTER)
    actions.perform()
    time.sleep(2)
    # Close the settings tab
    driver.close()
    # Switch back to the original tab
    driver.switch_to.window(driver.window_handles[0])

def main():
    filename = input("Enter the filename containing list of keywords (dorks): ")
    keywords = read_keywords_from_file(filename)
    
    driver = setup_driver()
    
    for keyword in keywords:
        attempt = 1
        while attempt <= 3:  # Coba hingga 3 kali jika terkena CAPTCHA
            clear_browser_data(driver)
            
            print(f"Scanning keyword '{keyword}' (Attempt {attempt})... ", end='', flush=True)
            html_source = get_google_search_results(driver, keyword)
            search_results = parse_google_search_results(html_source)
            
            if search_results == "captcha":
                print(f"\n{RED}CAPTCHA encountered. Clearing data and retrying...{RESET}")
                attempt += 1
                continue
            
            write_results_to_file(search_results, output_type='domain')
            write_results_to_file(search_results, output_type='fullurl')
            
            print(f"{GREEN}done{RESET}")
            break
    
    driver.quit()
    print(f"\n{GREEN}All scanning processes have been completed.{RESET}\n")

if __name__ == "__main__":
    main()
