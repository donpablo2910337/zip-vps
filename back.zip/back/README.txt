[ NOTE! ]
 - Do not delete anything or else scripts will be broke if you don't know it
 - Install Python 3.10.0
 - https://www.python.org/downloads/release/python-3100/ x64 bit

- Main Modules
pip3 install colorama ipranges requests click rich numpy twilio botocore boto3 futures mime termcolor configparser telegram_send bs4 discord_webhook numpy alive-progress  regex

[ Reminder ] Just Copy it and paste to terminal to install all modules need !


[ Expl0it_V4 ]
   - Premium Version ! !

 - Features 

- > EXPL0IT:
- Expl0it Shells: Uploaders, Wso, Filemanager
- Expl0it FTPs: SSH, FTP
- Bruteforce WordPress: Take Over Weak Accounts
- Webshell Alive Or Dead Checker
- Webshell Lookup Uname Servers

- > GRABBERS:
- Grab Domains By Date
- Zone-h Grabber Domains
- ReverseIP: api.webscan.cc, rapiddns.io, askdns.com

- > IPS:
- Domain To IPS
- Range IPS
- Generate Random IPS
- ASN IPS Grabber Asn Method To Get IPS

- > LARAVEL:
- Expl0it Laravel
- Auto Check Laravel: Apache Symfony, Wordpress site/ip
- Mass Check Sendgrid Limit: Send Test In Your Mail
- Mass Change User+Pass AWS: Send In Your Mail
- Auto Filter Mailist: Hotmail, Yahoo, Gmail

- > CRACKER:
- SMTPs Cracker Combos ( CUSTOM HOST )
- SMTPs Cracker Combos Unlimited
- Owa Webmail Cracker
- Crack cPanel | Whm | Webmail | SMTPs | WordPress from ComboList
- WordPress Login Checker | Filemanager | Plugins-Installed
-
- > CHECKER:
- Mass Check SMTPs: Send Test In Your Mail
- Mass Check FTP: SFTP, FTP, SSH

- > CONFIGURE:
- Sort Lines Lexicographically Ascending
- Add https:// & Http://
- Extract Domain
- Url to String
- Filter Custom Domain: .com, .net, .org
- Mass Scan http server
- Domain Clean Duplicate


 Removed All Bugs & Errors
 More Features More Experience
 
 If any problem unsolved Please Message: @exploitcs
 Community Telegram: @exploitsdotcs